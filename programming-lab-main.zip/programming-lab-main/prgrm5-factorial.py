print("Factorial of a Number \n")
a=int(input("Enter a Number : "))
x=1
for i in range(1,a+1):
	x=x*i
print(a,"! = ",x)
	
	
