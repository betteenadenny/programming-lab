print("Odd or Even \n")
a=int(input("Enter A Number : "))
if(a%2==0):
	print("Even")
else:
	print("Odd")

