print("Program to find Perimeter and Area of a Circle \n")
r=float(input("Enter the Radius of the Circle : "))
p=2*(3.1415926535898)*r
a=(3.1415926535898)*r*r
print("Perimeter of the Circle is ",p)
print("Area of the Circle is ",a)
