a=input("Enter String 1: ");
b=input("Enter String 2: ");
x=a.replace(a[0],b[0])+" "+b.replace(b[0],a[0])
print(x);