a=input("Enter Colours (Seperated by ,) : ")
a=a.split(",")
print("First Color is ",a[0],"\nLast Colour is ",a[len(a)-1])