Programming Lab - Lab Cycle 1

1) Find the area and perimeter of a circle

2) Convert degree celcius to farenheit

3) Swap 2 numbers without using temp variable

4) Check if the number is odd or even

5) Factorial of a number

6) Display future leap years from current year to a final year entered by user

7) Enter 2 list of integers, check 

    a) whether list are of same length

    b) whether list sums to same value

    c) whether any value occur in both

8) List Comprehension

    a) Generate positive list of numbers from a given list of integers

    b) Square of N numbers

    c) Form a list of vowels selected from a given word

    d) List ordinal value of each element of a word

9) Count occurrence of each word in a line of text.

10) Prompt the user for a list of integers for all values greater than 100, store "over" instead.

11) Store a list of first name, count occurrence of 'a' within the list

12) Get a string from an input string, where all occurrence of first character replaced with '$' except first character (Example Onion => Oni$n)

13) Create a string from a given string, where first and last characters exchanged (Example python => nythop)

14) Find biggest of 3 numbers entered

15) Accept a file name from user and print extension of that

16) Create a list of colors from comma seprated color names entered by user. Display first and last colors

17) Accept an integer N, and compute N + NN + NNN

18) Print out all colors from color-list1 not contained in color-list2

19) Create a single string seprated with space from 2 strings by swapping the character at position 1

20) From a list of integers, Create a list removing even numbers

21) Find GCD of 2 numbers

22) Sort dictionary in ascending and descending orders

23) Merge 2 dictionaries.
