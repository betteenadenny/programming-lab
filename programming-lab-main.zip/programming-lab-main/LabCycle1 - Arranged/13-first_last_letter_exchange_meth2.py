a=input("Enter A String : ")
x=a[0];
y=a[len(a)-1];
z=a[1:len(a)-1]
m=y+z+x
print(m)