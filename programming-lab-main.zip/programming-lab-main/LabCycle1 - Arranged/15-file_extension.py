a=input("Enter a File Name : ")
a=a.split(".")
print("File Extension is ",a[1])