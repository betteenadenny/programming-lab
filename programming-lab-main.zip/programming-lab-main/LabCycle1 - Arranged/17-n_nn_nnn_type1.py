n=int(input("Enter A Number N : "))
m=n+(n*n)+(n*n*n)
print("N + NN + NNN = ",m)