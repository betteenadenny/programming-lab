import math

a=int(input("Enter 1st Number : "))
b=int(input("Enter 2nd Number : "))
gcd=math.gcd(a,b)
print("GCD of Given Numbers : ",gcd)