print("Program to Covert Temperature in Celcius to Fahrenheit \n")
c=float(input("Enter Temperature in Celcius : "))
f=c*(1.8)+32
print("Given temp in Fahrenheit = ",f)

