print("Swapping \n")
a=int(input("Enter 1st Number : "))
b=int(input("Enter 2nd Number : "))
print("Before Swap")
print("A=",a," B=",b)
a,b=b,a
print("After Swap")
print("A=",a," B=",b)

