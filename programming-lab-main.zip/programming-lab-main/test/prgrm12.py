print("List Comprehension \n")

a=[1,3,5,-9,4,56,-12]
b=[x for x in a if x>0]
print("Given List = ",a)
print("+ve Number list = ",b)

c=[2,6,4,3]
d=[x*x for x in c]
print("\nGiven List = ",c)
print("Square of list Elements = ",d)


