print("Basic for loop")
a=int(input("Enter a Number : "))
for i in range(a):
	print(i)
