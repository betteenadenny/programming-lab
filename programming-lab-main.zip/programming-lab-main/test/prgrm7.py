print("Python Lists and append")
a=[1,2,3,4,5]
for i in a:
	print(i)
b=int(input("Enter a Number :"))
a.append(b)
print(a)

