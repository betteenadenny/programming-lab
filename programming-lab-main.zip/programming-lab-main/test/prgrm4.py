print("Even or Odd")
a=int(input("Enter A Number : "))
if(a%2==0):
	print("Even")
else:
	print("Odd")

