a=[1,-9,5,4,6,-8]
b=[]
for i in a:
	if i>0:
		b.append(i)
print("Given List = ",a)
print("Positive Numbers from Given list is = ", b)

