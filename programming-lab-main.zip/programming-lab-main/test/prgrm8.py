print("Empty List and Inserting Elements")
a=[]
b=int(input("Enter Number of Elements : "))
for i in range(b):
	c=int(input("Enter Element : "))
	a.append(c)
print(a)
