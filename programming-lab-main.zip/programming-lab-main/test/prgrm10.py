a=int(input("Enter Elements of the List : "))
b=[]
for i in a:
	if i>0:
		b.append(i)
print(a)

print(b)

