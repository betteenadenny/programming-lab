print("Factorial of a Number")
a=int(input("Enter a Number : "))
x=1
for i in range(1,a+1):
	x=x*i
print(a,"! = ",x)
	
	
